<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$lang['Hot Deals'] = 'Offre spéciale';
$lang['Create your store'] = 'Créez votre boutique';

$lang['Find your provider'] = 'Trouvez votre fournisseur';
$lang['My Account'] = 'Mon compte';
$lang['Sign out'] = 'Déconnexion';
$lang['Brands'] = 'Marques';
$lang['Category'] = 'Catégorie';


$lang['Sub Category'] = 'Sous-catégorie';
$lang['Product Name'] = 'Nom du produit';
$lang['Search'] = 'Rechercher';

$lang['Shop Hot Deals'] = 'Achetez des offres spécialess';
$lang['Our Top Categories'] = 'Nos meilleures catégories';
$lang['Our Featured Retailers'] = 'fournisseurs';
$lang['Discover the latest news, offers and exclusive promotions with our e-newsletter']  = 'Découvrez les dernières actualités, offres et promotions exclusives avec notre e-newsletter';

$lang['Sign up'] = 'Sign up';
$lang['Useful Links'] = 'Inscrivez-vous';
$lang['About BikeExchange'] = 'Liens utiles';
$lang['À propos de BikeExchange'] = 'À propos de Marketplacephones';
$lang['Social Connections'] = 'Connexions sociales';
$lang['Powered by'] = 'Powered by';

$lang['This information will appear in the advert listing'] = 'Cette information apparaîtra dans la liste de lannonce ';
$lang['Ships within Australia'] = 'Expédié en Europe ';
$lang['Buy online'] = 'Acheter en ligne';




?>