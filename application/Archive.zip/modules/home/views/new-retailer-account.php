<div class="CLayout-contentInner">


<div class="RetailerSplash">
<div class="RetailerSplash-headerPanel has-bottomMargin-xxlarge" style="margin-top:10px;background-image: url(<?php echo base_url().IMAGE_PATH_URL.BANNER_FOLDER.$content[0]->banner_image; ?>)">
<div class="RetailerSplash-headerPanelInner">
<div class="RetailerSplash-headerText">
<h1></h1>
</div>
<div class="RetailerSplash-headerSignupButton">
<a class="btn btn-go btn-large" href="<?php echo base_url();?>new-retailer-signup">Ingresar</a>
</div>
</div>
</div>

<?php 
	echo $content[0]->description;
?>



</div>