<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['Hot Deals'] = 'Hot Deals';
$lang['Create your store'] = 'Create your store';
$lang['Find your provider'] = 'Find your provider';
$lang['My Account'] = 'My Account';
$lang['Sign out'] = 'Sign out';
$lang['Brands'] = 'Brands';
$lang['Category'] = 'Category';
$lang['Sub Category'] = 'Sub Category';
$lang['Product Name'] = 'Product Name';
$lang['Search'] = 'Search';
$lang['Hot Deals'] = 'Hot Deals';
$lang['Shop Hot Deals'] = 'Shop Hot Deals';
$lang['Our Top Categories'] = 'Our Top Categories';
$lang['Our Featured Retailers'] = 'Our Featured Retailers';
$lang['Discover the latest news, offers and exclusive promotions with our e-newsletter'] = 'Discover the latest news, offers and exclusive promotions with our e-newsletter';
$lang['Sign up'] = 'Sign up';
$lang['Useful Links'] = 'Useful Links';
$lang['About BikeExchange'] = 'About BikeExchange';
$lang['Social Connections'] = 'Social Connections';
$lang['Powered by'] = 'Powered by';
$lang['This information will appear in the advert listing'] = 'This information will appear in the advert listing ';
$lang['Ships within Australia'] = 'Ships within Australia';
$lang['Buy online'] = 'Buy online';




?>