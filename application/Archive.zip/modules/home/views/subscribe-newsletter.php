<div class="CLayout-contentInner">
   <div class="HeaderBanner" id="HeaderAdvert">
      <div data-react-class="Banner"  class="BannerComponentWrapper"></div>
   </div>
  
   <div class="CLayout-fixedWidth">
      <div class="page-header">
         <h1 class="is-textCentered">Subscribe Newsletter</h1>
      </div>
      <div class="row">
         <div class="col-sm-8 col-sm-offset-2">
            <div class="DisplayPanel DisplayPanel--withShadow DisplayPanel--withBorder">
               <p class="lead">
                  Subscribe our newsletter to get updates
               </p>
                  <form class="new_password_reset" id="new_password_reset" action="javascript:void(0)" method="post"accept-charset="UTF-8" method="post">
                  <div class="error-newsletter"></div>     
                  <div class="MField">
                     <label for="user_email">Email</label>
                     <input required="required" type="email" name="user_email" id="user_email">
                  </div>
                  <button onclick="dosubscribe()" class="btn btn-large btn-primary">Subscribe</button>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>






 