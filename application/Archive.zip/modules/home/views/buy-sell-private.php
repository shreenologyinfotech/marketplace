

<div class="CLayout-fixedWidth">
<div class="PrivateItemLanding">
<div class="page-header">
<p class="is-textRightAligned is-shade50">
Eres una Tienda o un Distribuidor de productos para ciclismo?
<a href="<?php echo base_url();?>new-retailer-account" >Haz clic aquí</a>
</p>
<h1 class="is-textCentered">Vende tus artículos</h1>
</div>



</div>
</div>