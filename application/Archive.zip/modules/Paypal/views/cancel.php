<div class="bg-white">
<div class="page-title green-bg pt-3 pb-3">
  <div class="container">
   <div class="row">
    <div class="col col-12">
        <h2 class="text-uppercase text-center text-white"><?php echo  PAYMENT_UNSUCCESSFUL_TITLE; ?></h2>
    </div>
   </div>
  </div>
</div> 
 <div class="innerpages">
   <div class="container">
     <div class="row justify-content-center">
       <div class="col col-12">
         <div class="bg-light shadow p-5 mt-5 mb-5 rounded">
          <div class="mb-5 text-center">
           <h1 class="mb-4 mt-5 greentxt text-capitalize"><strong><?php echo OOPS; ?></strong></h1>
              <p><?php echo PAYMENT_HAS_BEEN_CANCEL;?></p>
             </div>    
            <div align="center">
              <a href="<?php echo base_url()?>" class="btn text-white pl-5 pr-5 mb-5 radius green-bg"><?php echo BACK_TO_HOME;?></a> </div>        
         </div>
       </div>
     </div>
   </div>
 </div>
 </div>
