<?php
  $orderId                    = "";
  $totalCost                  = site_currency_symbol()."0.00";
  $totalCostWithTransaction   = site_currency_symbol()."0.00";
  $remainBalance              = site_currency_symbol()."0.00";
  $transactionFee             = site_currency_symbol()."0.00";
  $startDate    = "";
  $endDate      = "";
  $qty          = "";
  $orderType    = "";
  $orderStatus  = "";
  $orderImage   = $this->config->item('upload_url')."ads/"."add-image.jpg";
  $userId       = "";
  $date = date_out();
  $postal_code  = "";
   
  $zipCodes     = "";
  if(sizeof($order_details) > 0){
     $result    = $order_details[0];
     $orderDispId  = $result->order_id;
     $orderId   = $result->id;
     $totalCost = site_currency_symbol().$result->total_cost;
     $totalCostWithTransaction = site_currency_symbol().($result->total_cost+$result->transaction_fee);
     $remainBalance = site_currency_symbol().$result->remaining_balance;
     $transactionFee = site_currency_symbol().$result->transaction_fee;
     
     $startDate    = date($date,strtotime($result->start_date));
     $endDate      = date($date,strtotime($result->end_date));
     $qty          = $result->quantity;
     $orderType    = $result->order_type;
     $orderStatus  = $result->status;

     if($result->image_path != ""){
        $orderImage   = $result->image_path;
     }
     $userId  = $result->user_id;
     $advertiserDetails = get_adveritser_details_by_id($userId);
     $zipCodes     = get_zip_code_by_order_id($result->id);
     if($result->order_lat !=  0 && $result->order_lng != 0){
        $postal_code  = postal_form_lat_lng($result->order_lat,$result->order_lng);
     }

  }




?>


<div class="row bg-title">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h4 class="page-title">View Order</h4> </div>
    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
        <a href="<?php echo base_url()?>orders" class="btn btn-info pull-right m-l-20 btn-rounded btn-outline hidden-xs hidden-sm waves-effect waves-light">Back</a>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url()?>admin/dashboard"><?php echo SITE_TITLE ;?></a></li>
            <li class="active">orders list</li>
        </ol>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->


<!-- /.row -->
<div class="row white-box">
     <div class="col col-6">         
       
      <?php /*
       <div class="mx-auto d-block text-center product-image">
         <img class="img-fluid order-image" src="<?php echo base_url().$orderImage;?>" alt="">
       </div>
      */
      $ad_image = json_decode($orderImage,true); ?>
       <div class="demo">
    <ul id="lightSlider">
       <?php 

       $defaultImage = get_cropped_image(600,600,'uploads/ads/add-image.jpg');

       if(!empty($ad_image)){
          foreach ($ad_image as $image) { 
            if($image != ''){
              $url="uploads/ads/".$image;
              if(file_exists($url)){
                $imgUrl  =   get_cropped_image(600,600,'uploads/ads/'.$image);
              }else{ 
                 $imgUrl = $defaultImage;
              }
            }else{ 
                $imgUrl  = $defaultImage;
            }?>
          <li class="d-flex align-items-center justify-content-center" data-thumb="<?php echo $imgUrl;?>" style="width:100%;height:400px;">
              <img src="<?php echo $imgUrl;?>"/>
           </li>
       <?php }
          }else{?>
            <li class="d-flex align-items-center justify-content-center" style="width:100%;height:400px;" data-thumb="<?php echo base_url()."uploads/ads/add-image.jpg";?>">
              <img src="<?php echo  $defaultImage ?>"/>
           </li>
          <?php 
          } 
      ?> 
    </ul>
</div>


     </div>
     <div class="col col-6">
       <div class="order-summery">
         <h3><a href="<?php echo base_url();?>admin/advertiser/view/<?php echo $userId; ?>"><?php echo $advertiserDetails[0]->fname." ".$advertiserDetails[0]->lname." 's order"; ?></a></h3>
         <p class="order-id d-inline-block"><b>Order Id:</b>  <?php echo get_order_id($orderId); ?></p>
         <span class="float-right greentxt"><b>Remaining Balance:</b> <?php echo $remainBalance;?></span>
         <br>
         <span class="float-right greentxt"><b>Total Views:</b> <?php echo $view_count;?></span>
         <span class="border-top d-block">&nbsp;</span>
           <div class="row">
             <div class="col col-6">
             <div class="form-group">
               <label>Start Date</label>
               <div class="date"> <span><?php echo $startDate;?></span> </div>                
             </div>
             </div>
             <div class="col col-6">
             <div class="form-group">
               <label>End Date</label>
               <div class="date"> <span><?php echo $endDate;?></span> </div>                 
             </div>
             </div>
             
             
             <div class="col col-12">
             <span class="border-top d-block">&nbsp;</span>
          <label class=" mb-4">Selected Area</label>            
          <div class="custom-control col-12 mb-3 custom-radio">             
            
            <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
            <label class="custom-control-label" for="customRadio1">
                <?php if($orderType == "Whole Country"){
                  echo "Whole Singapore";
                }else if($orderType == "Specific Postal Code"){
                  echo "By Postal Sector ".$zipCodes;  
                }else{
                  echo "Within 500m Radius of Postal Code ".$postal_code;
                }?>
                  

            </label>
          
          </div>
          </div>
             <div class="col col-12">
             <span class="border-top d-block">&nbsp;</span>
             <label class="mb-4">Quantity:</label>
             <div class="form-group mt-2 col- col-6">                
               <div class="date">
                    <input readonly="" value="<?php echo $qty;?>" type="text" class="form-control radius" placeholder="200">
                  </div>                
             </div>
             </div>
             <div class="col col-12">
             <label class="mt-4 mb-4">Total Cost : <?php echo  $totalCost;?></label>
             <div class="form-row">                
               <div class="date d-inline col col-6">
                  <span class="col col-6">*Inclusive of <?php echo  $transactionFee;?> transaction fee</span>             
             </div>
             </div>
          </div>

          <?php

          if($orderStatus == "Pending Approval"){ ?>
               <button onclick="performActionWithRedirection('<?php echo base_url()?>ajax/approveorder/<?php echo  $orderId;?>','Are you sure?','Once order is approved, you would not be able to undo this.','Order has been approved','<?php echo base_url()?>admin/orders')" class="mt-4 btn btn-success waves-effect waves-light m-r-10">Approve Order</button>    
          <?php } ?>

          <?php


           // 'Pending Approval','Refunded','Completed','Cancelled Order','Pending Distribution','In Progress','Pending Payment','Deleted','Cancelled Request'
         /* 
          if($orderStatus == "Pending Approval"){ ?>
               <button onclick="performAction('<?php echo base_url()?>ajax/approveorder/<?php echo  $orderId;?>','Are you sure!','You want to Approve this order!!','order approved successfullly')" class="mt-4 btn btn-success waves-effect waves-light m-r-10">Approve Order</button>    
          <?php } 

           if($orderStatus != "Cancelled Order" && $orderStatus != "Cancelled Request" && $orderStatus != "Deleted"){ ?>
               <button onclick="performAction('<?php echo base_url()?>ajax/cancelorder/<?php echo  $orderId;?>','Are you sure!','You want to Cancel this order!!','order Cancel successfullly')" class="mt-4 btn btn-danger waves-effect waves-light m-r-10">Cancel  Order</button>
          <?php }  

          if($orderStatus != "Deleted"){ ?>
                <button  onclick="performAction('<?php echo base_url()?>ajax/deleteorder/<?php echo  $orderId;?>','Are you sure!','You want to Delete this order!!','order Delete successfullly')" class="mt-4 btn btn-danger waves-effect waves-light m-r-10">Delete order</button>
          <?php } 

          if($orderStatus  == "Cancelled Request"){ ?>
               <button  onclick="performAction('<?php echo base_url()?>ajax/acceptcancelrequest/<?php echo  $orderId;?>','Are you sure!','You want to accept cancel request this order!!','cancel request accepted successfullly')" class="mt-4 btn btn-danger waves-effect waves-light m-r-10">Accept Cancellation</button>
          <?php } ?>

          */ ?>

          
       </div>
     </div>
    
</div>

</div>
 
    
 