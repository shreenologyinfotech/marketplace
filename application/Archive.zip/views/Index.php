<?php //$this->load->view('Includes/header_script'); ?>
<div class="app app-header-fixed  ">
    <div id="content"  role="main">
        <div class="app-content-body ">
        	<div class="homeBox">
            	<div class="homeLogo"><img src="<?php /*echo base_url() */?>assets/img/logo.png"  /></div>
                <h1>Welcome To Dalal</h1>
       <?php
            //$this->load->view('Includes/msg_alert');
            ?>
            </div>
        </div>
    </div>
</div>
<?php //$this->load->view('Includes/footer_scripts'); ?>
</body>
</html>
