<?php
class Order extends Master{
    function __construct(){
        parent::__construct();
        $this->table = 'tbl_orders';
        $this->primaryKeyField = 'id';
        parent::__construct();       
    }
}

?>
