<div class="bg-white">
 <div class="innerpages pt-5 pb-4">
   <div class="container">
        <?php echo $data[0]->content;?>
   </div>
 </div>
</div>    
    
    
