<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['Hot Deals'] =  'Ofertas especiales';
$lang['Create your store'] ='Crea tu tienda';
$lang['Find your provider'] = 'Encuentra tu proveedor';
$lang['My Account'] = 'Mi cuenta';
$lang['Sign out'] = 'Cerrar sesión';
$lang['Brands'] =  'Marcas';
$lang['Category'] =  'Categoría';
$lang['Sub Category'] = 'Subcategoría';
$lang['Product Name'] = 'Nombre del producto';
$lang['Search'] = 'Buscar';
$lang['Hot Deals'] =  'Ofertas especiales';
$lang['Shop Hot Deals'] = 'Comprar ofertas especiales';
$lang['Our Top Categories'] = 'Nuestras categorías principales';
$lang['Our Featured Retailers'] = 'Nuestros minoristas destacados';
$lang['Discover the latest news, offers and exclusive promotions with our e-newsletter'] = 'Descubra las últimas noticias, ofertas y promociones exclusivas con nuestro boletín electrónico';
$lang['Sign up'] = 'Registrarse';
$lang['Useful Links'] = 'Enlaces útiles';
$lang['About BikeExchange'] = 'Acerca de Marketplacephones';
$lang['Social Connections'] = 'Conexiones sociales';
$lang['Powered by'] = 'Desarrollado por';
$lang['This information will appear in the advert listing '] = 'Esta información aparecerá en la lista de anuncios';
$lang['Ships within Australia'] = 'Envíos dentro de Australia';
$lang['Buy online'] = 'Comprar en línea';


?>