<div class="bg-white">
<div class="page-title green-bg pt-3 pb-3">
  <div class="container">
   <div class="row">
    <div class="col col-12">
        <h2 class="text-uppercase text-center text-white"><?php echo  PAYMENT_SUCCESS_TITLE; ?></h2>
    </div>
    
   </div>
  </div>
</div> 
 <div class="innerpages">
   <div class="container">
     <div class="row justify-content-center">
       <div class="col col-12">
         <div class="bg-light shadow p-5 mt-5 mb-5 rounded">
          <div class="mb-5 text-center">
           <h1 class="mb-4 mt-5 greentxt text-capitalize"><strong><?php echo THANK_YOU;?></strong></h1>
              <p>You have completed your order successfully<br>
             </div>    
            <div align="center">
              <a href="<?php echo base_url()?>" class="btn text-white pl-5 pr-5 mb-5 radius green-bg">Back to Home</a> </div>        
         </div>
       </div>
     </div>
   </div>
 </div>
 </div>
 