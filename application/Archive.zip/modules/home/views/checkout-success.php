<div class="LeadPanel has-bg40 is-textCentered">
   <div class="LeadPanel-text is-shade100">
      Thank You For Order With Us
   </div>
</div>
<div class="CLayout-fixedWidth clearfix">
   <div class="row">
      
      <div class="col-sm-12">
         <section class="DisplayPanel">
            <div class="is-textCentered">
               <div class="Circle has-bottomMargin-small has-topMargin-large has-localeBgColor is-shade100">
                  <div class="Circle-text">
                     <i class="fa fa-user"></i>
                  </div>
               </div>
               <h1 class="has-noTopMargin">
                  Thank you for your order
               </h1>
               <p>
                  <!-- <a href="<?php // echo base_url();?>myaccount/myorders">Click here</a> -->
               </p>
               <br>
            </div>
            
         </section>
      </div>
   </div>
</div>

