<?php
//$lang['here_key'] = 'here value'; 

?>